#include "stm32f10x.h"                  // Device header
#include "Delay.h"

void ADCInit(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1|RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIOLED_Inits;
	GPIOLED_Inits.GPIO_Mode=GPIO_Mode_AIN;           //设置为模拟输入
	GPIOLED_Inits.GPIO_Pin=GPIO_Pin_1;
	GPIOLED_Inits.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIOLED_Inits);
	
	RCC_ADCCLKConfig(RCC_PCLK2_Div6);                //ADC时钟分频
	ADC_DeInit(ADC1);                                //复位ADC1
	
	ADC_InitTypeDef ADCFirst;
	ADCFirst.ADC_ContinuousConvMode=DISABLE;         //
	ADCFirst.ADC_DataAlign=ADC_DataAlign_Right;      //设置数据右对齐还是左对齐(这里设置右对齐)
	ADCFirst.ADC_ExternalTrigConv=ADC_ExternalTrigConv_None;           //设置是否外部触发(这里不使用外部触发)
	ADCFirst.ADC_Mode=ADC_Mode_Independent;               //设置为独立模式
	ADCFirst.ADC_NbrOfChannel=1;                          //设置有几个通道
	ADCFirst.ADC_ScanConvMode=DISABLE;                    //是否使用扫描模式(这里设置不适用  )
	ADC_Init(ADC1,&ADCFirst);
	
	ADC_Cmd(ADC1,ENABLE);                                        //使能ADC1
	ADC_ResetCalibration(ADC1);                                  //使能复位校准
	while(ADC_GetResetCalibrationStatus(ADC1));                  //等待复位校准结束
	ADC_StartCalibration(ADC1);                                  //开启AD校准
	while(ADC_GetCalibrationStatus(ADC1));                       //等待校准结束
	
}

u16 GET_ADC(u8 ch){
	ADC_RegularChannelConfig(ADC1,ch,1,ADC_SampleTime_239Cycles5);      //配置规则通道(哪个ADC;哪个通道;在规则序列之间是第几个转换;采样时间)
	ADC_SoftwareStartConvCmd(ADC1,ENABLE);                        //开启软件转换
	while(!ADC_GetFlagStatus(ADC1,ADC_FLAG_EOC));                   //等待转换结束
	return ADC_GetConversionValue(ADC1);                          //返还获取的入口参数
}

u16 GET_ADC_Average(u8 ch,u8 times){                           //循环获取后求出平均值
	u32 val=0;
	u8 t;
	for(t=0;t<times;t++){
		val+=GET_ADC(ch);
		Delay_ms(5);
	}
	return val/times;
}
