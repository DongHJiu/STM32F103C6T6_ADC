#ifndef __ADC_H
#define __ADC_H

void ADCInit(void);
u16 GET_ADC(u8 ch);
u16 GET_ADC_Average(u8 ch,u8 times);


#endif
