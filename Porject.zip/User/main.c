#include "stm32f10x.h"                  // Device header
#include "OLED.h"
#include "Delay.h"
#include "LED.h"
#include "ADC.h"

float data;
float temp;

int main(void){
	ADCInit();
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_WriteBit(GPIOB,GPIO_Pin_7,Bit_RESET);	
	OLED_Init();
	while(1){
		data=GET_ADC_Average(ADC_Channel_1,10);   //设置通道一循环获取10次
		temp=data*(3.3/4096);                     //这里转换为电压值(因为ADC数据是12位存储的(最大值就为4096),而最大输入电压是3.3V)
		OLED_ShowNum(1,1,data,3);

	}
}
